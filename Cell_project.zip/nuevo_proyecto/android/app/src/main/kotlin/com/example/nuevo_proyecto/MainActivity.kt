package com.example.nuevo_proyecto

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
